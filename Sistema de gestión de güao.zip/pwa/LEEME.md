# ¡güao! — App móvil (PWA) · Guía de instalación

Esta carpeta es tu **aplicación instalable** en celular (Android/iOS) y computador.
Ya incluye: cotizador, ventas, **gestión de cobro**, clientes, inventario, filtros por
columna en cada tabla, y **sincronización en la nube con Supabase** (inicio de sesión
con correo/clave — los datos ya no dependen del navegador de cada equipo).

## Archivos
- `index.html` — la aplicación
- `manifest.webmanifest` — nombre, ícono y colores de la app
- `sw.js` — permite que abra sin internet (los datos igual requieren conexión para sincronizar)
- `icon-192.png`, `icon-512.png` — íconos de la marca

## Cómo publicarla en internet (1 solo paso, ~2 minutos)
1. Entra a **https://app.netlify.com/drop** (no necesitas cuenta para probarlo, pero
   te recomiendo crear una gratis para poder actualizar el sitio después).
2. Arrastra **toda esta carpeta `pwa`** (no el .zip, la carpeta descomprimida) a la página.
3. Netlify te da una URL pública al instante, ej. `https://guao-tienda.netlify.app`.
4. (Opcional) en Netlify → **Site settings → Change site name** para un nombre más lindo,
   ej. `guao-originalbrands.netlify.app`.

**Ese mismo link sirve para todo: computador, Android e iPhone.** No hay que publicar nada
por separado para cada plataforma — es una sola URL.

## Cómo "instalarla" como app en el celular
- **Android (Chrome):** abre la URL → menú (⋮) → **"Instalar aplicación"**.
- **iPhone (Safari):** abre la URL → botón compartir → **"Agregar a pantalla de inicio"**.

Aparecerá el ícono de ¡güao! como una app normal, a pantalla completa.

## Los datos ya son compartidos ✅
Como la app quedó conectada a Supabase, iniciar sesión desde el celular o el computador
muestra **los mismos datos en tiempo real** — no hace falta exportar/importar para mover
información entre equipos. Igual conserva el botón de **Exportar a Excel / respaldo .json**
como copia de seguridad adicional.

## Si actualizas la app más adelante
Cada vez que se hagan cambios de diseño o funcionalidad, hay que volver a arrastrar la
carpeta actualizada a Netlify (o conectar un repositorio de GitHub para que se actualice
sola). Los datos no se pierden — viven en Supabase, no en este archivo.
